import { Subscription, User } from '../types';

const USER_SESSION_KEY = 'stacklens_user_session_v1';
const USERS_DB_KEY = 'stacklens_users_db_v1';

// Simulate DB latency
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const StorageService = {
  // --- Session Management ---
  getUserSession: (): User | null => {
    const data = localStorage.getItem(USER_SESSION_KEY);
    return data ? JSON.parse(data) : null;
  },

  saveUserSession: (user: User): void => {
    localStorage.setItem(USER_SESSION_KEY, JSON.stringify(user));
  },

  clearUserSession: (): void => {
    localStorage.removeItem(USER_SESSION_KEY);
  },

  // --- User Database (Simulated Auth) ---
  findUserByEmail: async (email: string) => {
    await delay(200);
    const db = JSON.parse(localStorage.getItem(USERS_DB_KEY) || '{}');
    return db[email] || null;
  },

  createUser: async (email: string, password: string, name: string): Promise<User> => {
    await delay(500);
    const db = JSON.parse(localStorage.getItem(USERS_DB_KEY) || '{}');
    
    if (db[email]) {
      throw new Error('User already exists');
    }

    const newUser: User = {
      id: 'usr_' + Date.now(),
      email,
      name,
    };

    // Store user + simple password (in real app, hash this!)
    db[email] = { 
      password, 
      user: newUser 
    };
    
    localStorage.setItem(USERS_DB_KEY, JSON.stringify(db));
    return newUser;
  },

  verifyCredentials: async (email: string, password: string): Promise<User> => {
    await delay(500);
    
    // Ensure DB has a demo user if empty (for smoother POC experience)
    let db = JSON.parse(localStorage.getItem(USERS_DB_KEY) || '{}');
    if (Object.keys(db).length === 0) {
        const demoUser = {
            id: 'usr_demo',
            email: 'demo@stacklens.com',
            name: 'Demo User'
        };
        db['demo@stacklens.com'] = { password: 'password', user: demoUser };
        localStorage.setItem(USERS_DB_KEY, JSON.stringify(db));
        // Reload db
        db = JSON.parse(localStorage.getItem(USERS_DB_KEY) || '{}');
    }

    const record = db[email];

    if (!record) {
      throw new Error('Account does not exist. Please sign up.');
    }

    if (record.password !== password) {
      throw new Error('Incorrect password.');
    }

    return record.user;
  },

  // --- Subscriptions (Scoped by User ID) ---
  
  getUserSubKey: (userId: string) => `stacklens_subscriptions_v1_${userId}`,

  getSubscriptions: async (userId: string): Promise<Subscription[]> => {
    await delay(300); // Fake network delay
    const key = StorageService.getUserSubKey(userId);
    const data = localStorage.getItem(key);
    
    if (!data) {
      // Return empty array for new users
      return [];
    }
    return JSON.parse(data);
  },

  saveSubscriptions: async (userId: string, subs: Subscription[]): Promise<void> => {
    await delay(300);
    const key = StorageService.getUserSubKey(userId);
    localStorage.setItem(key, JSON.stringify(subs));
  },

  updateSubscription: async (userId: string, updatedSub: Subscription): Promise<Subscription[]> => {
    const current = await StorageService.getSubscriptions(userId);
    const updated = current.map(s => s.id === updatedSub.id ? updatedSub : s);
    await StorageService.saveSubscriptions(userId, updated);
    return updated;
  },

  removeSubscription: async (userId: string, subscriptionId: string): Promise<Subscription[]> => {
    const current = await StorageService.getSubscriptions(userId);
    const updated = current.filter(s => s.id !== subscriptionId);
    await StorageService.saveSubscriptions(userId, updated);
    return updated;
  }
};