import { GoogleGenAI, Type } from "@google/genai";
import { Subscription, OptimizationSuggestion } from "../types";

// Helper to interact with Gemini
export const analyzeSubscriptions = async (subscriptions: Subscription[]): Promise<OptimizationSuggestion[]> => {
  if (!process.env.API_KEY) {
    console.error("No API KEY found");
    return [
      {
        id: 'error_1',
        title: 'API Key Missing',
        description: 'Please set your Google Gemini API Key to enable AI analysis.',
        potentialSavings: 0,
        confidenceScore: 0,
        actionType: 'consolidate'
      }
    ];
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `
    Analyze the following list of software and cloud subscriptions.
    Identify potential cost savings, redundancies (e.g., paying for both Claude Pro and ChatGPT Plus if usage is low on one), or unused resources (e.g., low usagePercent).
    
    Subscriptions Data:
    ${JSON.stringify(subscriptions, null, 2)}
    
    Return a list of specific, actionable optimization suggestions.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: "You are a FinOps and SaaS optimization expert. Your goal is to save the user money without hindering productivity.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              potentialSavings: { type: Type.NUMBER },
              confidenceScore: { type: Type.NUMBER },
              actionType: { type: Type.STRING, enum: ['cancel', 'downgrade', 'consolidate'] }
            },
            required: ['id', 'title', 'description', 'potentialSavings', 'confidenceScore', 'actionType']
          }
        }
      }
    });

    const jsonText = response.text;
    if (!jsonText) return [];
    
    return JSON.parse(jsonText) as OptimizationSuggestion[];
  } catch (error) {
    console.error("Error analyzing with Gemini:", error);
    return [];
  }
};