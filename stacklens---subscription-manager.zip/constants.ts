import { Subscription, SubscriptionStatus, BillingCycle, ProviderDirectoryItem } from './types';

export const INITIAL_SUBSCRIPTIONS: Subscription[] = [
  {
    id: 'sub_1',
    name: 'ChatGPT Plus',
    provider: 'OpenAI',
    icon: '🟢',
    cost: 20.00,
    currency: 'USD',
    cycle: BillingCycle.MONTHLY,
    status: SubscriptionStatus.ACTIVE,
    renewalDate: new Date(new Date().setDate(new Date().getDate() + 5)).toISOString(),
    usagePercent: 85,
    category: 'AI Model',
    autoRenewal: true
  },
  {
    id: 'sub_2',
    name: 'Claude Pro',
    provider: 'Anthropic',
    icon: '🟠',
    cost: 20.00,
    currency: 'USD',
    cycle: BillingCycle.MONTHLY,
    status: SubscriptionStatus.ACTIVE,
    renewalDate: new Date(new Date().setDate(new Date().getDate() + 12)).toISOString(),
    usagePercent: 12,
    category: 'AI Model',
    autoRenewal: false
  },
  {
    id: 'sub_3',
    name: 'Cursor Pro',
    provider: 'Cursor',
    icon: '🔵',
    cost: 20.00,
    currency: 'USD',
    cycle: BillingCycle.MONTHLY,
    status: SubscriptionStatus.ACTIVE,
    renewalDate: new Date(new Date().setDate(new Date().getDate() + 20)).toISOString(),
    usagePercent: 95,
    category: 'Productivity',
    autoRenewal: true
  }
];

export const MOCK_AWS_SUBSCRIPTIONS: Subscription[] = [
  {
    id: 'aws_1',
    name: 'EC2 Instances (t3.medium)',
    provider: 'AWS',
    icon: '🟧',
    cost: 42.50,
    currency: 'USD',
    cycle: BillingCycle.PAYG,
    status: SubscriptionStatus.ACTIVE,
    renewalDate: new Date(new Date().setDate(1)).toISOString(), // 1st of next month
    usagePercent: 100,
    category: 'Infrastructure',
    autoRenewal: true
  },
  {
    id: 'aws_2',
    name: 'RDS (PostgreSQL)',
    provider: 'AWS',
    icon: '🟧',
    cost: 65.00,
    currency: 'USD',
    cycle: BillingCycle.PAYG,
    status: SubscriptionStatus.ACTIVE,
    renewalDate: new Date(new Date().setDate(1)).toISOString(),
    usagePercent: 40,
    category: 'Infrastructure',
    autoRenewal: true
  },
  {
    id: 'aws_3',
    name: 'S3 Standard Storage',
    provider: 'AWS',
    icon: '🟧',
    cost: 12.30,
    currency: 'USD',
    cycle: BillingCycle.PAYG,
    status: SubscriptionStatus.ACTIVE,
    renewalDate: new Date(new Date().setDate(1)).toISOString(),
    usagePercent: 20,
    category: 'Infrastructure',
    autoRenewal: true
  },
  {
    id: 'aws_4',
    name: 'Idle Elastic IP',
    provider: 'AWS',
    icon: '🟧',
    cost: 3.50,
    currency: 'USD',
    cycle: BillingCycle.PAYG,
    status: SubscriptionStatus.ACTIVE,
    renewalDate: new Date(new Date().setDate(1)).toISOString(),
    usagePercent: 0, // Unused!
    category: 'Infrastructure',
    autoRenewal: true
  }
];

export const PROVIDER_DIRECTORY: ProviderDirectoryItem[] = [
  { id: 'openai', name: 'OpenAI', category: 'AI', icon: '🟢', authMethod: 'apikey', description: 'ChatGPT, API usage, and DALL-E.' },
  { id: 'anthropic', name: 'Anthropic', category: 'AI', icon: '🟠', authMethod: 'apikey', description: 'Claude Pro and API usage.' },
  { id: 'cursor', name: 'Cursor', category: 'Productivity', icon: '🔵', authMethod: 'oauth', description: 'AI Code Editor subscriptions.' },
  { id: 'aws', name: 'AWS', category: 'Cloud', icon: '🟧', authMethod: 'apikey', description: 'Amazon Web Services infrastructure.' },
  { id: 'github', name: 'GitHub Copilot', category: 'DevTools', icon: '⚫', authMethod: 'oauth', description: 'AI coding assistant.' },
  { id: 'notion', name: 'Notion AI', category: 'Productivity', icon: '⚪', authMethod: 'oauth', description: 'Workspace and AI add-ons.' },
  { id: 'vercel', name: 'Vercel', category: 'Cloud', icon: '▲', authMethod: 'oauth', description: 'Frontend cloud and deployments.' },
  { id: 'midjourney', name: 'Midjourney', category: 'AI', icon: '⛵', authMethod: 'oauth', description: 'Generative image AI.' },
  { id: 'azure', name: 'Azure', category: 'Cloud', icon: '🔷', authMethod: 'apikey', description: 'Microsoft Cloud Computing.' },
  { id: 'gcp', name: 'Google Cloud', category: 'Cloud', icon: '🌈', authMethod: 'oauth', description: 'Google Cloud Platform.' },
  { id: 'elevenlabs', name: 'ElevenLabs', category: 'AI', icon: '🔊', authMethod: 'apikey', description: 'AI Voice Generator.' },
  { id: 'linear', name: 'Linear', category: 'Productivity', icon: '🟣', authMethod: 'oauth', description: 'Issue tracking tool.' },
  { id: 'adobe', name: 'Adobe Creative Cloud', category: 'Productivity', icon: '🟥', authMethod: 'oauth', description: 'Photoshop, Illustrator, Firefly.' },
  { id: 'figma', name: 'Figma', category: 'Productivity', icon: '🎨', authMethod: 'oauth', description: 'Collaborative interface design.' },
  { id: 'miro', name: 'Miro', category: 'Productivity', icon: '🟨', authMethod: 'oauth', description: 'Visual collaboration platform.' },
  { id: 'drawio', name: 'Draw.io', category: 'Productivity', icon: '✏️', authMethod: 'oauth', description: 'Diagramming and whiteboarding.' },
  { id: 'lovable', name: 'Lovable', category: 'AI', icon: '💜', authMethod: 'oauth', description: 'AI-powered full-stack app builder.' },
];