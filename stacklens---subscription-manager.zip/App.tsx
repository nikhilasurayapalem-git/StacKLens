import React, { useState, useMemo, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { StorageService } from './services/storage';
import { Subscription } from './types';
import { Card } from './components/ui/Card';
import { Button } from './components/ui/Button';
import { SpendingTrendChart, CategoryPieChart } from './components/Charts';
import { SubscriptionTable } from './components/SubscriptionTable';
import { OptimizationPanel } from './components/OptimizationPanel';
import { ConnectModal } from './components/ConnectModal';
import { Layout } from './components/Layout';
import { LoginPage } from './components/auth/LoginPage';

type ViewState = 'dashboard' | 'subscriptions' | 'settings';

const DashboardContent: React.FC = () => {
  const { user } = useAuth();
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [currentView, setCurrentView] = useState<ViewState>('dashboard');

  // Load data on mount or when user changes
  useEffect(() => {
    const loadData = async () => {
      if (!user) return;
      setIsLoading(true);
      try {
        // Pass user.id to scope data to the specific user
        const subs = await StorageService.getSubscriptions(user.id);
        setSubscriptions(subs);
      } catch (e) {
        console.error("Failed to load subscriptions", e);
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, [user]);

  const connectedProviders = useMemo(() => {
    return Array.from(new Set(subscriptions.map(s => s.provider)));
  }, [subscriptions]);

  const totalMonthlySpend = useMemo(() => {
    return subscriptions.reduce((acc, sub) => acc + sub.cost, 0);
  }, [subscriptions]);

  const topCategory = useMemo(() => {
    if (subscriptions.length === 0) return 'None';
    const cats: Record<string, number> = {};
    subscriptions.forEach(sub => cats[sub.category] = (cats[sub.category] || 0) + sub.cost);
    return Object.entries(cats).sort((a, b) => b[1] - a[1])[0]?.[0] || 'None';
  }, [subscriptions]);

  const handleConnectProvider = async (newSubs: Subscription[]) => {
    if (!user) return;
    // Optimistically update UI
    const updatedList = [...subscriptions, ...newSubs];
    setSubscriptions(updatedList);
    // Persist to storage for this user
    await StorageService.saveSubscriptions(user.id, updatedList);
  };

  const handleToggleAutoRenewal = async (id: string) => {
    if (!user) return;
    // Optimistically update UI
    const updatedSubs = subscriptions.map(sub => 
      sub.id === id ? { ...sub, autoRenewal: !sub.autoRenewal } : sub
    );
    setSubscriptions(updatedSubs);
    
    // Persist
    const sub = subscriptions.find(s => s.id === id);
    if (sub) {
        await StorageService.updateSubscription(user.id, {...sub, autoRenewal: !sub.autoRenewal});
    }
  };

  const handleRemoveSubscription = async (id: string) => {
    if (!user) return;
    if (window.confirm("Are you sure you want to remove this subscription?")) {
        // Optimistically update UI
        const updatedSubs = subscriptions.filter(sub => sub.id !== id);
        setSubscriptions(updatedSubs);
        // Persist
        await StorageService.removeSubscription(user.id, id);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <Layout currentView={currentView} setCurrentView={setCurrentView}>
        {/* VIEW: DASHBOARD */}
        {currentView === 'dashboard' && (
          <>
            <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
              <div>
                <h2 className="text-2xl font-bold text-white">Welcome back, {user?.name}</h2>
                <p className="text-slate-400">Manage your AI toolkit spend in one place.</p>
              </div>
              <Button onClick={() => setIsConnectModalOpen(true)}>
                + Connect Provider
              </Button>
            </header>

            {/* Stats Row */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card className="bg-gradient-to-br from-slate-800 to-slate-800/50">
                <p className="text-slate-400 text-sm font-medium">Total Monthly Spend</p>
                <div className="mt-2 flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-white">${totalMonthlySpend.toFixed(2)}</span>
                  {subscriptions.length > 0 && (
                    <span className="text-sm text-green-400 flex items-center">
                        <svg className="w-3 h-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                        </svg>
                        12%
                    </span>
                  )}
                </div>
              </Card>
              <Card>
                <p className="text-slate-400 text-sm font-medium">Active Subscriptions</p>
                <div className="mt-2 flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-white">{subscriptions.length}</span>
                  <span className="text-sm text-slate-500">across {connectedProviders.length} providers</span>
                </div>
              </Card>
              <Card>
                <p className="text-slate-400 text-sm font-medium">Top Spending Category</p>
                <div className="mt-2">
                  <span className="text-2xl font-bold text-white">{topCategory}</span>
                </div>
              </Card>
            </div>

            {/* Content: Empty State or Dashboard Grid */}
            {subscriptions.length === 0 ? (
                <div className="col-span-full flex flex-col items-center justify-center p-12 bg-slate-800/30 rounded-2xl border border-slate-800 border-dashed text-center">
                    <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mb-6 shadow-xl">
                        <svg className="w-10 h-10 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                        </svg>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">No Subscriptions Yet</h3>
                    <p className="text-slate-400 max-w-sm mb-8">
                        Connect your cloud or AI providers to start visualizing your spending and usage.
                    </p>
                    <Button onClick={() => setIsConnectModalOpen(true)} size="lg">
                        Connect First Provider
                    </Button>
                </div>
            ) : (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                {/* Charts Column */}
                <div className="lg:col-span-2 space-y-6">
                    <Card title="Spending Trend">
                    <SpendingTrendChart subscriptions={subscriptions} />
                    </Card>
                    <Card title="Spend by Category">
                    <CategoryPieChart subscriptions={subscriptions} />
                    </Card>
                    <Card title="Active Subscriptions">
                    <SubscriptionTable 
                        subscriptions={subscriptions} 
                        onToggleAutoRenewal={handleToggleAutoRenewal} 
                        onRemove={handleRemoveSubscription}
                    />
                    </Card>
                </div>

                {/* Sidebar Column */}
                <div className="space-y-6">
                    <OptimizationPanel subscriptions={subscriptions} />
                    
                    <Card title="Upcoming Renewals">
                        <div className='space-y-4'>
                            {subscriptions
                                .sort((a,b) => new Date(a.renewalDate).getTime() - new Date(b.renewalDate).getTime())
                                .slice(0, 3)
                                .map(sub => (
                                <div key={sub.id} className='flex justify-between items-center pb-3 border-b border-slate-700 last:border-0'>
                                    <div>
                                        <p className='text-white font-medium'>{sub.name}</p>
                                        <p className='text-xs text-slate-400'>{new Date(sub.renewalDate).toLocaleDateString()}</p>
                                    </div>
                                    <span className='text-white'>${sub.cost.toFixed(2)}</span>
                                </div>
                            ))}
                        </div>
                    </Card>
                </div>
                </div>
            )}
          </>
        )}

        {/* VIEW: SUBSCRIPTIONS */}
        {currentView === 'subscriptions' && (
          <div className="space-y-6">
            <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
              <div>
                <h2 className="text-2xl font-bold text-white">Subscriptions</h2>
                <p className="text-slate-400">Detailed view of all connected services and costs.</p>
              </div>
              <Button onClick={() => setIsConnectModalOpen(true)}>
                + Connect Provider
              </Button>
            </header>

            <Card>
                {subscriptions.length > 0 ? (
                    <SubscriptionTable 
                        subscriptions={subscriptions} 
                        onToggleAutoRenewal={handleToggleAutoRenewal} 
                        onRemove={handleRemoveSubscription}
                    />
                ) : (
                    <div className="text-center py-12 text-slate-500">
                        No subscriptions found. Connect a provider to get started.
                    </div>
                )}
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <Card title="Connected Providers">
                 <div className="space-y-2">
                   {connectedProviders.length > 0 ? connectedProviders.map(provider => (
                     <div key={provider} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                        <span className="text-white font-medium">{provider}</span>
                        <span className="text-xs px-2 py-1 bg-green-500/10 text-green-400 border border-green-500/20 rounded-full">Connected</span>
                     </div>
                   )) : (
                       <p className="text-sm text-slate-500 italic">No providers connected yet.</p>
                   )}
                 </div>
               </Card>
            </div>
          </div>
        )}

        {/* VIEW: SETTINGS */}
        {currentView === 'settings' && (
          <div className="space-y-6">
            <header>
               <h2 className="text-2xl font-bold text-white">Settings</h2>
               <p className="text-slate-400">Manage application preferences and API keys.</p>
            </header>

            <Card title="General Configuration">
               <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Currency</label>
                    <select className="bg-slate-900 border border-slate-700 text-white text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5">
                      <option>USD ($)</option>
                      <option>EUR (€)</option>
                      <option>GBP (£)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Notification Email</label>
                    <input type="email" value={user?.email || ''} disabled className="bg-slate-900/50 border border-slate-700 text-slate-500 text-sm rounded-lg block w-full p-2.5 cursor-not-allowed" />
                  </div>
               </div>
            </Card>

            <Card title="API Connections">
               <div className="p-4 bg-indigo-900/20 rounded-lg border border-indigo-500/30">
                  <div className="flex items-center gap-3">
                     <div className="p-2 bg-indigo-500 rounded-lg">
                        <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                     </div>
                     <div>
                        <h4 className="font-semibold text-white">Google Gemini API</h4>
                        <p className="text-sm text-slate-400">Used for optimization suggestions.</p>
                     </div>
                     <div className="ml-auto">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Active
                        </span>
                     </div>
                  </div>
               </div>
            </Card>
          </div>
        )}

      <ConnectModal 
        isOpen={isConnectModalOpen}
        onClose={() => setIsConnectModalOpen(false)}
        onConnect={handleConnectProvider}
        connectedProviders={connectedProviders}
      />
    </Layout>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <MainRouter />
    </AuthProvider>
  );
};

const MainRouter: React.FC = () => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return user ? <DashboardContent /> : <LoginPage />;
};

export default App;