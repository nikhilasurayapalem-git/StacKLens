export enum ProviderType {
  CHATGPT = 'ChatGPT',
  CLAUDE = 'Claude',
  CURSOR = 'Cursor',
  AWS = 'AWS',
  GITHUB = 'GitHub Copilot',
  NOTION = 'Notion AI',
  VERCEL = 'Vercel',
  MIDJOURNEY = 'Midjourney'
}

export enum SubscriptionStatus {
  ACTIVE = 'Active',
  CANCELED = 'Canceled',
  PAUSED = 'Paused',
  TRIAL = 'Trial'
}

export enum BillingCycle {
  MONTHLY = 'Monthly',
  YEARLY = 'Yearly',
  PAYG = 'Pay-as-you-go'
}

export interface User {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
}

export interface Subscription {
  id: string;
  name: string;
  provider: string; // Changed to string to support any provider
  icon?: string; // Emoji or icon url
  cost: number;
  currency: string;
  cycle: BillingCycle;
  status: SubscriptionStatus;
  renewalDate: string; // ISO Date string
  usagePercent: number; // 0-100, estimated usage
  category: 'AI Model' | 'Infrastructure' | 'Productivity' | 'Creative';
  logoUrl?: string;
  autoRenewal: boolean;
}

export interface SpendingHistoryPoint {
  month: string;
  amount: number;
}

export interface OptimizationSuggestion {
  id: string;
  title: string;
  description: string;
  potentialSavings: number;
  confidenceScore: number; // 0-1
  actionType: 'cancel' | 'downgrade' | 'consolidate';
}

export interface ProviderDirectoryItem {
  id: string;
  name: string;
  category: 'AI' | 'Cloud' | 'DevTools' | 'Productivity';
  icon: string;
  authMethod: 'oauth' | 'apikey';
  description: string;
}