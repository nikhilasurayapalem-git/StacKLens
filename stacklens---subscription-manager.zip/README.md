# StackLens 🟢

StackLens is a web-based dashboard that helps developers and teams track, visualize, and optimize their AI and Cloud infrastructure subscriptions.

## Features

- **Unified Dashboard**: View spending across ChatGPT, AWS, Claude, and more.
- **AI Optimization**: Uses Google Gemini to analyze spending and suggest cost-saving measures.
- **Simulated Auth**: Secure login and sign-up flow (Proof of Concept).
- **Visualization**: Interactive charts for spending trends and category breakdowns.

## Tech Stack

- React 18
- TypeScript
- Tailwind CSS
- Recharts
- Google Gemini SDK
- Vite

## Setup

1. Clone the repository.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create a `.env` file and add your Google Gemini API Key:
   ```
   API_KEY=your_gemini_api_key_here
   ```
4. Run the development server:
   ```bash
   npm run dev
   ```

## Deployment

This project is configured for deployment on Netlify.