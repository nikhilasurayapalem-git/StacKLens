import React, { useState } from 'react';
import { Subscription, OptimizationSuggestion } from '../types';
import { analyzeSubscriptions } from '../services/geminiService';
import { Button } from './ui/Button';
import { Card } from './ui/Card';

interface OptimizationPanelProps {
  subscriptions: Subscription[];
}

export const OptimizationPanel: React.FC<OptimizationPanelProps> = ({ subscriptions }) => {
  const [suggestions, setSuggestions] = useState<OptimizationSuggestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasRun, setHasRun] = useState(false);

  const handleAnalyze = async () => {
    setLoading(true);
    const results = await analyzeSubscriptions(subscriptions);
    setSuggestions(results);
    setLoading(false);
    setHasRun(true);
  };

  return (
    <Card 
      title="AI Optimization Hub" 
      className="h-full border-indigo-500/30 shadow-indigo-500/10 shadow-lg relative overflow-hidden"
    >
        {/* Background decorative effect */}
      <div className="absolute top-0 right-0 -mt-10 -mr-10 w-40 h-40 bg-indigo-500 rounded-full blur-[80px] opacity-20 pointer-events-none"></div>

      <div className="space-y-6 relative z-10">
        <p className="text-slate-400">
          Let our Gemini-powered engine analyze your spending patterns, usage overlap, and redundancies to find savings.
        </p>
        
        {!hasRun && (
          <div className="flex flex-col items-center justify-center py-8">
            <div className="mb-4 p-4 bg-indigo-500/10 rounded-full text-indigo-400">
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
            </div>
            <Button onClick={handleAnalyze} isLoading={loading} size="lg" className="w-full sm:w-auto">
              Run AI Analysis
            </Button>
          </div>
        )}

        {hasRun && suggestions.length === 0 && !loading && (
           <div className="text-center py-8 text-slate-400">
             <p>Great job! No obvious optimizations found. Your stack is lean.</p>
             <Button onClick={handleAnalyze} variant="ghost" size="sm" className="mt-4">Run again</Button>
           </div>
        )}

        <div className="space-y-4">
          {suggestions.map((suggestion) => (
            <div key={suggestion.id} className="bg-slate-900/50 rounded-lg p-4 border border-slate-700/50 hover:border-indigo-500/50 transition-colors">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-semibold text-white">{suggestion.title}</h4>
                <span className={`text-xs px-2 py-1 rounded bg-slate-800 ${
                  suggestion.confidenceScore > 0.8 ? 'text-green-400' : 'text-yellow-400'
                }`}>
                  {Math.round(suggestion.confidenceScore * 100)}% Confidence
                </span>
              </div>
              <p className="text-sm text-slate-400 mb-3">{suggestion.description}</p>
              <div className="flex items-center justify-between">
                <div className="text-green-400 font-bold text-sm">
                  Potential Savings: ${suggestion.potentialSavings.toFixed(2)}/mo
                </div>
                <Button size="sm" variant="secondary" onClick={() => alert("This would open the provider cancellation/settings page.")}>
                  {suggestion.actionType === 'cancel' ? 'Cancel Subscription' : 'Review Plan'}
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        {hasRun && suggestions.length > 0 && (
            <div className='flex justify-center pt-4'>
                 <Button onClick={handleAnalyze} variant="ghost" size="sm" isLoading={loading}>Refresh Analysis</Button>
            </div>
        )}
      </div>
    </Card>
  );
};