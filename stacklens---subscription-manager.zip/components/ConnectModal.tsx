import React, { useState, useMemo } from 'react';
import { PROVIDER_DIRECTORY, MOCK_AWS_SUBSCRIPTIONS } from '../constants';
import { Subscription, BillingCycle, SubscriptionStatus, ProviderDirectoryItem } from '../types';
import { Button } from './ui/Button';

interface ConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnect: (subscriptions: Subscription[]) => void;
  connectedProviders: string[];
}

type Step = 'select' | 'auth' | 'manual' | 'success';

export const ConnectModal: React.FC<ConnectModalProps> = ({ isOpen, onClose, onConnect, connectedProviders }) => {
  const [step, setStep] = useState<Step>('select');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProvider, setSelectedProvider] = useState<ProviderDirectoryItem | null>(null);
  const [apiKey, setApiKey] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Manual entry state
  const [manualForm, setManualForm] = useState({
    name: '',
    cost: '',
    date: ''
  });

  const filteredProviders = useMemo(() => {
    return PROVIDER_DIRECTORY.filter(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      p.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery]);

  const resetModal = () => {
    setStep('select');
    setSearchQuery('');
    setSelectedProvider(null);
    setApiKey('');
    setIsAuthenticating(false);
    setAuthError(null);
    setManualForm({ name: '', cost: '', date: '' });
  };

  const handleClose = () => {
    resetModal();
    onClose();
  };

  const handleProviderSelect = (provider: ProviderDirectoryItem) => {
    if (connectedProviders.includes(provider.name)) return;
    setSelectedProvider(provider);
    setStep('auth');
    setAuthError(null);
  };

  const handleAuthenticate = async () => {
    // In production: Validate API Key with backend or perform OAuth redirect
    if (selectedProvider?.authMethod === 'apikey' && apiKey.length < 5) {
      setAuthError('Please enter a valid API Key.');
      return;
    }

    setIsAuthenticating(true);
    setAuthError(null);

    // Simulate Network Request
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Mock Validation Success
    setIsAuthenticating(false);
    setStep('success');

    // Prepare Mock Data
    setTimeout(() => {
      if (selectedProvider) {
        let newSubs: Subscription[] = [];
        
        if (selectedProvider.id === 'aws') {
          newSubs = MOCK_AWS_SUBSCRIPTIONS;
        } else {
          // Generic mock for other providers
          newSubs = [{
            id: `new_${selectedProvider.id}_${Date.now()}`,
            name: `${selectedProvider.name} Pro Plan`,
            provider: selectedProvider.name,
            icon: selectedProvider.icon,
            cost: 29.99,
            currency: 'USD',
            cycle: BillingCycle.MONTHLY,
            status: SubscriptionStatus.ACTIVE,
            renewalDate: new Date(new Date().setDate(new Date().getDate() + 30)).toISOString(),
            usagePercent: Math.floor(Math.random() * 100),
            category: selectedProvider.category === 'Cloud' ? 'Infrastructure' : 'AI Model',
            autoRenewal: true
          }];
        }
        
        onConnect(newSubs);
        handleClose();
      }
    }, 1500);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualForm.name || !manualForm.cost || !manualForm.date) {
        setAuthError('All fields are required.');
        return;
    }

    const newSub: Subscription = {
        id: `manual_${Date.now()}`,
        name: manualForm.name,
        provider: 'Manual Entry',
        icon: '📝',
        cost: parseFloat(manualForm.cost),
        currency: 'USD',
        cycle: BillingCycle.MONTHLY,
        status: SubscriptionStatus.ACTIVE,
        renewalDate: new Date(manualForm.date).toISOString(),
        usagePercent: 0,
        category: 'Productivity', // Default
        autoRenewal: true
    };

    setStep('success');
    setTimeout(() => {
        onConnect([newSub]);
        handleClose();
    }, 1000);
  };
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 rounded-xl shadow-2xl w-full max-w-2xl border border-slate-700 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-700 flex justify-between items-center bg-slate-800">
          <div>
            <h3 className="text-xl font-bold text-white">
              {step === 'select' && 'Connect New Provider'}
              {step === 'auth' && `Connect to ${selectedProvider?.name}`}
              {step === 'manual' && 'Add Subscription Manually'}
              {step === 'success' && 'Connection Successful'}
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              {step === 'select' && 'Search integrations or add manually for accurate tracking.'}
              {step === 'auth' && 'Authenticate securely to import subscription data.'}
              {step === 'manual' && 'Enter accurate details for your subscription.'}
            </p>
          </div>
          <button onClick={handleClose} className="text-slate-400 hover:text-white transition-colors">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6">
          
          {/* STEP 1: SELECT PROVIDER */}
          {step === 'select' && (
            <div className="space-y-4">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <svg className="h-5 w-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
                <input
                  type="text"
                  className="block w-full pl-10 pr-3 py-3 border border-slate-700 rounded-lg leading-5 bg-slate-800 text-slate-300 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Search providers (e.g. OpenAI, AWS, Vercel)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
                {filteredProviders.map((provider) => {
                  const isConnected = connectedProviders.includes(provider.name);
                  return (
                    <button
                      key={provider.id}
                      onClick={() => handleProviderSelect(provider)}
                      disabled={isConnected}
                      className={`flex items-center p-4 rounded-lg border text-left transition-all ${
                        isConnected
                          ? 'bg-slate-800/50 border-slate-800 opacity-50 cursor-not-allowed'
                          : 'bg-slate-800 border-slate-700 hover:bg-slate-700 hover:border-indigo-500 hover:shadow-lg hover:shadow-indigo-500/10'
                      }`}
                    >
                      <div className="text-3xl mr-4">{provider.icon}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center mb-1">
                            <span className="font-semibold text-white truncate">{provider.name}</span>
                            {isConnected && <span className="text-[10px] uppercase bg-green-500/20 text-green-400 px-1.5 py-0.5 rounded">Connected</span>}
                        </div>
                        <p className="text-xs text-slate-400 truncate">{provider.description}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
              
              {/* Manual Entry Option */}
              <div className="pt-6 border-t border-slate-700 mt-6">
                 <p className="text-sm text-slate-400 mb-3">Can't find what you're looking for?</p>
                 <button 
                   onClick={() => setStep('manual')}
                   className="w-full flex items-center justify-center p-3 border border-dashed border-slate-600 rounded-lg text-slate-400 hover:text-white hover:border-indigo-500 hover:bg-slate-800/50 transition-all"
                 >
                    <svg className="w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                    Add Custom Subscription Manually
                 </button>
              </div>
            </div>
          )}

          {/* STEP 2: AUTHENTICATE */}
          {step === 'auth' && selectedProvider && (
            <div className="max-w-md mx-auto py-4">
              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center text-4xl mx-auto mb-4 border border-slate-700 shadow-xl">
                  {selectedProvider.icon}
                </div>
                <h4 className="text-lg font-medium text-white">Connect {selectedProvider.name}</h4>
                <p className="text-sm text-slate-400 mt-2">
                  We need permission to access your billing and usage data to provide insights.
                </p>
              </div>

              <div className="space-y-6">
                {selectedProvider.authMethod === 'apikey' ? (
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      API Key / Access Token
                    </label>
                    <input
                      type="password"
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      className="block w-full px-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder={`Enter your ${selectedProvider.name} API Key`}
                    />
                    <p className="mt-2 text-xs text-slate-500">
                      Your key is encrypted and stored locally in your browser session for this demo.
                    </p>
                  </div>
                ) : (
                  <div className="text-center p-6 bg-slate-800 rounded-lg border border-slate-700 border-dashed">
                    <p className="text-sm text-slate-300 mb-4">
                      You will be redirected to {selectedProvider.name} to authorize access.
                    </p>
                    {/* In production: Button would be <a href="/api/auth/provider"> */}
                    <div className="space-y-3">
                         <div className="bg-slate-900 p-4 rounded text-left">
                            <label className="block text-xs font-semibold text-slate-500 mb-1">SIMULATED PROVIDER LOGIN</label>
                            <input 
                                type="password" 
                                placeholder="Enter any password to authorize" 
                                className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-sm text-white focus:outline-none focus:border-indigo-500"
                            />
                         </div>
                        <Button variant="secondary" className="w-full" onClick={handleAuthenticate} isLoading={isAuthenticating}>
                        Authorize Access
                        </Button>
                    </div>
                  </div>
                )}

                {authError && (
                  <div className="p-3 rounded bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                    {authError}
                  </div>
                )}

                <div className="flex gap-3 pt-4">
                  <Button variant="ghost" className="flex-1" onClick={() => setStep('select')}>
                    Back
                  </Button>
                  {selectedProvider.authMethod === 'apikey' && (
                    <Button 
                        className="flex-1" 
                        onClick={handleAuthenticate}
                        isLoading={isAuthenticating}
                    >
                        Verify & Connect
                    </Button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* STEP: MANUAL ENTRY */}
          {step === 'manual' && (
              <div className='max-w-md mx-auto'>
                  <form onSubmit={handleManualSubmit} className='space-y-4'>
                      <div>
                          <label className='block text-sm font-medium text-slate-300 mb-1'>Service Name</label>
                          <input 
                            type="text" 
                            required
                            className="w-full px-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white focus:ring-indigo-500 focus:border-indigo-500"
                            placeholder="e.g. Netflix, DigitalOcean"
                            value={manualForm.name}
                            onChange={e => setManualForm({...manualForm, name: e.target.value})}
                          />
                      </div>
                      <div className='grid grid-cols-2 gap-4'>
                          <div>
                            <label className='block text-sm font-medium text-slate-300 mb-1'>Monthly Cost ($)</label>
                            <input 
                                type="number" 
                                step="0.01"
                                required
                                className="w-full px-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white focus:ring-indigo-500 focus:border-indigo-500"
                                placeholder="0.00"
                                value={manualForm.cost}
                                onChange={e => setManualForm({...manualForm, cost: e.target.value})}
                            />
                          </div>
                          <div>
                            <label className='block text-sm font-medium text-slate-300 mb-1'>Next Renewal</label>
                            <input 
                                type="date" 
                                required
                                className="w-full px-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white focus:ring-indigo-500 focus:border-indigo-500"
                                value={manualForm.date}
                                onChange={e => setManualForm({...manualForm, date: e.target.value})}
                            />
                          </div>
                      </div>
                      
                      {authError && (
                        <div className="p-3 rounded bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                            {authError}
                        </div>
                      )}

                      <div className="flex gap-3 pt-6">
                        <Button variant="ghost" className="flex-1" onClick={() => setStep('select')}>
                            Back
                        </Button>
                        <Button type="submit" className="flex-1">
                            Add Subscription
                        </Button>
                      </div>
                  </form>
              </div>
          )}

          {/* STEP 3: SUCCESS */}
          {step === 'success' && (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mb-6 animate-bounce">
                <svg className="w-10 h-10 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h4 className="text-2xl font-bold text-white mb-2">Success!</h4>
              <p className="text-slate-400 max-w-sm mx-auto">
                 Subscription added successfully.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};