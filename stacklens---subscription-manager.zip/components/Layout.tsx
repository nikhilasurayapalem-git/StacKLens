import React from 'react';
import { useAuth } from '../contexts/AuthContext';

type ViewState = 'dashboard' | 'subscriptions' | 'settings';

interface LayoutProps {
  children: React.ReactNode;
  currentView: ViewState;
  setCurrentView: (view: ViewState) => void;
}

interface NavItemProps {
  view: ViewState;
  label: string;
  icon: React.ReactNode;
  currentView: ViewState;
  setCurrentView: (view: ViewState) => void;
}

const NavItem: React.FC<NavItemProps> = ({ view, label, icon, currentView, setCurrentView }) => (
  <button
    onClick={() => setCurrentView(view)}
    className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
      currentView === view
        ? 'bg-indigo-500/10 text-indigo-400'
        : 'text-slate-400 hover:bg-slate-800 hover:text-white'
    }`}
  >
    {icon}
    {label}
  </button>
);

export const Layout: React.FC<LayoutProps> = ({ children, currentView, setCurrentView }) => {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col md:flex-row">
      <aside className="w-full md:w-64 bg-slate-950 border-r border-slate-800 flex-shrink-0 flex flex-col">
        <div className="p-6">
          <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-400 to-cyan-400 bg-clip-text text-transparent">
            StackLens
          </h1>
          <p className="text-xs text-slate-500 mt-1">Visualize. Optimize. Control.</p>
        </div>
        
        <nav className="px-3 space-y-1 flex-1">
          <NavItem 
            view="dashboard" 
            label="Dashboard" 
            currentView={currentView}
            setCurrentView={setCurrentView}
            icon={
              <svg className="mr-3 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
              </svg>
            }
          />
          <NavItem 
            view="subscriptions" 
            label="Subscriptions" 
            currentView={currentView}
            setCurrentView={setCurrentView}
            icon={
              <svg className="mr-3 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
              </svg>
            }
          />
          <NavItem 
            view="settings" 
            label="Settings" 
            currentView={currentView}
            setCurrentView={setCurrentView}
            icon={
              <svg className="mr-3 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
              </svg>
            }
          />
        </nav>

        <div className="p-6 border-t border-slate-800">
            <div className='flex items-center gap-3 mb-4'>
                <div className='w-2 h-2 rounded-full bg-green-500 animate-pulse'></div>
                <span className='text-xs text-slate-400'>System Operational</span>
            </div>
            <div className="flex items-center justify-between">
                <p className="text-xs text-slate-600 truncate max-w-[120px]">
                    {user?.email}
                </p>
                <button 
                  onClick={logout}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  Sign Out
                </button>
            </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-4 md:p-8">
        {children}
      </main>
    </div>
  );
};