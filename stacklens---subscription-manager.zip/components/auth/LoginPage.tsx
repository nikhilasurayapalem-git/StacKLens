import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../ui/Button';

export const LoginPage: React.FC = () => {
  const { login, register, error } = useAuth();
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    if (!email || !password) {
      setLocalError("Email and password are required.");
      return;
    }
    if (isSignUp && !name) {
      setLocalError("Name is required for sign up.");
      return;
    }

    setLoading(true);
    try {
      if (isSignUp) {
        await register(email, password, name);
      } else {
        await login(email, password);
      }
    } catch (err: any) {
      // Error is handled in context and displayed via `error` prop or caught here
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const toggleMode = () => {
    setIsSignUp(!isSignUp);
    setLocalError(null);
    // Clear fields when switching unless we are switching to login to use demo creds
    if (!isSignUp) {
       setEmail('');
       setPassword('');
       setName('');
    }
  };

  const fillDemoCredentials = () => {
    setIsSignUp(false);
    setEmail('demo@stacklens.com');
    setPassword('password');
    setLocalError(null);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl p-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-400 to-cyan-400 bg-clip-text text-transparent mb-2">
            StackLens
          </h1>
          <p className="text-slate-400">
            {isSignUp ? 'Create an account to track your spend.' : 'Sign in to manage your AI subscriptions.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {isSignUp && (
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-slate-300 mb-1">
                Full Name
              </label>
              <input
                id="name"
                type="text"
                className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
                placeholder="John Doe"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
          )}

          <div>
            <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-1">
              Email Address
            </label>
            <input
              id="email"
              type="email"
              className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
              placeholder="you@company.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-slate-300 mb-1">
              Password
            </label>
            <input
              id="password"
              type="password"
              className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          {(error || localError) && (
            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm text-center">
              {localError || error}
            </div>
          )}

          <Button 
            type="submit" 
            className="w-full py-3 text-lg" 
            isLoading={loading}
          >
            {isSignUp ? 'Create Account' : 'Sign In'}
          </Button>

          <div className="text-center space-y-3">
            <button 
              type="button" 
              onClick={toggleMode}
              className="text-sm text-indigo-400 hover:text-indigo-300 transition-colors block w-full"
            >
              {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
            </button>
            
            {!isSignUp && (
              <button 
                type="button"
                onClick={fillDemoCredentials}
                className="text-xs text-slate-500 hover:text-slate-400 underline"
              >
                Use Demo Account (demo@stacklens.com)
              </button>
            )}
          </div>
        </form>
        
        <div className="mt-8 pt-6 border-t border-slate-700">
            <p className="text-center text-xs text-slate-500 mb-4">Or continue with</p>
            <div className="grid grid-cols-2 gap-4">
                <button type="button" className="flex items-center justify-center px-4 py-2 border border-slate-700 rounded-lg bg-slate-900 hover:bg-slate-700 transition-colors text-white text-sm">
                GitHub
                </button>
                <button type="button" className="flex items-center justify-center px-4 py-2 border border-slate-700 rounded-lg bg-slate-900 hover:bg-slate-700 transition-colors text-white text-sm">
                Google
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};