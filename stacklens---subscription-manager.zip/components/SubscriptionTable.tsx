import React from 'react';
import { Subscription, SubscriptionStatus } from '../types';

interface SubscriptionTableProps {
  subscriptions: Subscription[];
  onToggleAutoRenewal?: (id: string) => void;
  onRemove?: (id: string) => void;
}

const StatusBadge: React.FC<{ status: SubscriptionStatus }> = ({ status }) => {
  const styles = {
    [SubscriptionStatus.ACTIVE]: 'bg-green-500/10 text-green-400 border-green-500/20',
    [SubscriptionStatus.CANCELED]: 'bg-red-500/10 text-red-400 border-red-500/20',
    [SubscriptionStatus.PAUSED]: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
    [SubscriptionStatus.TRIAL]: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  };

  return (
    <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${styles[status]}`}>
      {status}
    </span>
  );
};

const UsageBar: React.FC<{ percent: number }> = ({ percent }) => {
  let colorClass = 'bg-green-500';
  if (percent < 30) colorClass = 'bg-red-500'; // Low usage is bad (waste)
  else if (percent < 70) colorClass = 'bg-yellow-500';

  return (
    <div className="flex items-center gap-2">
      <div className="w-24 h-2 bg-slate-700 rounded-full overflow-hidden">
        <div className={`h-full ${colorClass} transition-all duration-500`} style={{ width: `${percent}%` }}></div>
      </div>
      <span className="text-xs text-slate-400">{percent}%</span>
    </div>
  );
};

export const SubscriptionTable: React.FC<SubscriptionTableProps> = ({ subscriptions, onToggleAutoRenewal, onRemove }) => {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm text-slate-400">
        <thead className="bg-slate-900/50 text-xs uppercase font-semibold text-slate-300">
          <tr>
            <th className="px-6 py-4 rounded-tl-lg">Service</th>
            <th className="px-6 py-4">Category</th>
            <th className="px-6 py-4">Status</th>
            <th className="px-6 py-4">Usage Est.</th>
            <th className="px-6 py-4">Renewal</th>
            <th className="px-6 py-4">Auto-renew</th>
            <th className="px-6 py-4 text-right">Cost</th>
            <th className="px-6 py-4 rounded-tr-lg"></th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-700">
          {subscriptions.map((sub) => (
            <tr key={sub.id} className="hover:bg-slate-800/50 transition-colors">
              <td className="px-6 py-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-lg shadow-inner">
                    {sub.icon ? sub.icon : sub.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-medium text-white">{sub.name}</div>
                    <div className="text-xs text-slate-500">{sub.provider}</div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">{sub.category}</td>
              <td className="px-6 py-4"><StatusBadge status={sub.status} /></td>
              <td className="px-6 py-4"><UsageBar percent={sub.usagePercent} /></td>
              <td className="px-6 py-4">{new Date(sub.renewalDate).toLocaleDateString()}</td>
              <td className="px-6 py-4">
                {onToggleAutoRenewal && (
                  <button
                    onClick={() => onToggleAutoRenewal(sub.id)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-slate-900 ${
                      sub.autoRenewal ? 'bg-indigo-600' : 'bg-slate-700'
                    }`}
                    title={`Turn ${sub.autoRenewal ? 'off' : 'on'} auto-renewal`}
                  >
                    <span className="sr-only">Toggle auto-renewal</span>
                    <span
                      className={`${
                        sub.autoRenewal ? 'translate-x-6' : 'translate-x-1'
                      } inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 ease-in-out`}
                    />
                  </button>
                )}
                {!onToggleAutoRenewal && (
                    <span className={`text-xs ${sub.autoRenewal ? 'text-green-400' : 'text-slate-500'}`}>
                        {sub.autoRenewal ? 'On' : 'Off'}
                    </span>
                )}
              </td>
              <td className="px-6 py-4 text-right font-medium text-white">
                ${sub.cost.toFixed(2)}
                <span className="text-xs text-slate-500 font-normal ml-1">/{sub.cycle === 'Monthly' ? 'mo' : 'yr'}</span>
              </td>
              <td className="px-6 py-4 text-right">
                {onRemove && (
                  <button 
                    onClick={() => onRemove(sub.id)}
                    className="text-slate-500 hover:text-red-400 transition-colors p-2 rounded-md hover:bg-red-500/10"
                    title="Remove subscription"
                  >
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};